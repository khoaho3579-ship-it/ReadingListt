package com.freddy.readinglist.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "reading_items")
data class ReadingItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val title: String,
    val url: String,
    val notes: String,
    val favorite: Boolean = false,
    val createdAt: Long,
    val updatedAt: Long
)
