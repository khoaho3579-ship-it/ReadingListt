package com.freddy.readinglist.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "settings")

class SettingsStore(private val context: Context) {

    private val FAVORITES_ONLY = booleanPreferencesKey("favorites_only")

    val favoritesOnly: Flow<Boolean> =
        context.dataStore.data.map { it[FAVORITES_ONLY] ?: false }

    suspend fun setFavoritesOnly(value: Boolean) {
        context.dataStore.edit { it[FAVORITES_ONLY] = value }
    }
}
