package com.freddy.readinglist.ui

import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.runtime.Composable
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.freddy.readinglist.AppContainer

object Routes {
    const val HOME = "home"
    const val LIST = "list"
    const val SETTINGS = "settings"
    const val DETAIL = "detail"
    const val EDIT = "edit"
    fun detail(id: Long) = "$DETAIL/$id"
    fun edit(id: Long) = "$EDIT/$id"
}

@Composable
fun AppNav(container: AppContainer) {
    val nav = rememberNavController()

    NavHost(
        navController = nav,
        startDestination = Routes.HOME,
        enterTransition = {
            slideInHorizontally(tween(300)) { it / 6 } + fadeIn(tween(300))
        },
        exitTransition = { fadeOut(tween(200)) },
        popEnterTransition = { fadeIn(tween(200)) },
        popExitTransition = {
            slideOutHorizontally(tween(300)) { it / 6 } + fadeOut(tween(200))
        }
    ) {
        composable(Routes.HOME) {
            HomeScreen(
                container = container,
                onOpenList = { nav.navigate(Routes.LIST) },
                onOpenDetail = { nav.navigate(Routes.detail(it)) },
                onGetStarted = { nav.navigate(Routes.edit(-1L)) },
                onOpenSettings = { nav.navigate(Routes.SETTINGS) }
            )
        }
        composable(Routes.LIST) {
            ListScreen(
                container = container,
                onBack = { nav.popBackStack() },
                onOpenDetail = { nav.navigate(Routes.detail(it)) },
                onCreate = { nav.navigate(Routes.edit(-1L)) },
                onOpenSettings = { nav.navigate(Routes.SETTINGS) }
            )
        }
        composable(
            route = "${Routes.DETAIL}/{id}",
            arguments = listOf(navArgument("id") { type = NavType.LongType })
        ) {
            val id = it.arguments?.getLong("id") ?: -1L
            DetailScreen(
                container = container,
                id = id,
                onBack = { nav.popBackStack() },
                onEdit = { nav.navigate(Routes.edit(id)) }
            )
        }
        composable(
            route = "${Routes.EDIT}/{id}",
            arguments = listOf(navArgument("id") { type = NavType.LongType })
        ) {
            val id = it.arguments?.getLong("id") ?: -1L
            EditScreen(
                container = container,
                id = id,
                onBack = { nav.popBackStack() }
            )
        }
        composable(Routes.SETTINGS) {
            SettingsScreen(container = container, onBack = { nav.popBackStack() })
        }
    }
}
