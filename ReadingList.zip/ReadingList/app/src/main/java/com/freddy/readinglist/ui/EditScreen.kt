package com.freddy.readinglist.ui

import android.net.Uri
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.freddy.readinglist.AppContainer
import com.freddy.readinglist.data.ReadingRepository
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class EditViewModel(private val repo: ReadingRepository, private val id: Long) : ViewModel() {

    var title by mutableStateOf("")
        private set
    var url by mutableStateOf("")
        private set
    var notes by mutableStateOf("")
        private set
    var titleError by mutableStateOf<String?>(null)
        private set
    var urlError by mutableStateOf<String?>(null)
        private set
    var saving by mutableStateOf(false)
        private set
    var loaded by mutableStateOf(id == -1L)
        private set

    val isNew: Boolean = id == -1L

    init {
        if (id != -1L) {
            viewModelScope.launch {
                repo.byId(id).first()?.let {
                    title = it.title
                    url = it.url
                    notes = it.notes
                }
                loaded = true
            }
        }
    }

    fun onTitleChange(v: String) { title = v; if (titleError != null) titleError = null }
    fun onUrlChange(v: String) { url = v; if (urlError != null) urlError = null }
    fun onNotesChange(v: String) { notes = v }

    fun save(onSaved: () -> Unit) {
        val t = title.trim()
        if (t.isEmpty()) { titleError = "Title is required"; return }

        val normalized = normalizeUrl(url.trim())
        if (normalized.isNotEmpty() && !isValidUrl(normalized)) {
            urlError = "Enter a valid URL (e.g. example.com)"
            return
        }

        viewModelScope.launch {
            saving = true
            if (id == -1L) {
                repo.create(t, normalized, notes)
            } else {
                repo.byId(id).first()?.let {
                    repo.update(it.copy(title = t, url = normalized, notes = notes.trim()))
                }
            }
            saving = false
            onSaved()
        }
    }

    private fun normalizeUrl(s: String): String = when {
        s.isBlank() -> ""
        s.startsWith("http://") || s.startsWith("https://") -> s
        else -> "https://$s"
    }

    private fun isValidUrl(s: String): Boolean = try {
        val uri = Uri.parse(s)
        (uri.scheme == "http" || uri.scheme == "https") && !uri.host.isNullOrBlank()
    } catch (_: Exception) {
        false
    }
}

class EditViewModelFactory(
    private val repo: ReadingRepository,
    private val id: Long
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T = EditViewModel(repo, id) as T
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditScreen(container: AppContainer, id: Long, onBack: () -> Unit) {
    val vm: EditViewModel = viewModel(factory = EditViewModelFactory(container.repository, id))

    Scaffold(
        containerColor = MaterialTheme.colorScheme.surface,
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        if (vm.isNew) "New item" else "Edit item",
                        style = MaterialTheme.typography.titleLarge
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { inner ->
        if (!vm.loaded) {
            Box(Modifier.fillMaxSize().padding(inner), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
            return@Scaffold
        }
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(inner)
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            OutlinedTextField(
                value = vm.title,
                onValueChange = vm::onTitleChange,
                label = { Text("Title *") },
                isError = vm.titleError != null,
                supportingText = vm.titleError?.let { { Text(it) } },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                singleLine = true
            )
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(
                value = vm.url,
                onValueChange = vm::onUrlChange,
                label = { Text("Link") },
                placeholder = { Text("example.com") },
                isError = vm.urlError != null,
                supportingText = vm.urlError?.let { { Text(it) } },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                singleLine = true
            )
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(
                value = vm.notes,
                onValueChange = vm::onNotesChange,
                label = { Text("Notes") },
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 140.dp),
                shape = RoundedCornerShape(16.dp),
                minLines = 5
            )
            Spacer(Modifier.height(24.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedButton(
                    onClick = onBack,
                    modifier = Modifier.weight(1f).height(56.dp),
                    shape = RoundedCornerShape(28.dp)
                ) { Text("Cancel") }
                Button(
                    onClick = { vm.save { onBack() } },
                    enabled = !vm.saving,
                    modifier = Modifier.weight(1f).height(56.dp),
                    shape = RoundedCornerShape(28.dp)
                ) {
                    Icon(Icons.Rounded.Check, null, Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(if (vm.saving) "Saving…" else "Save")
                }
            }
        }
    }
}
