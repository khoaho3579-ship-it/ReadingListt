package com.freddy.readinglist.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface ReadingDao {

    @Query("SELECT * FROM reading_items ORDER BY updatedAt DESC")
    fun observeAll(): Flow<List<ReadingItem>>

    @Query("SELECT * FROM reading_items WHERE favorite = 1 ORDER BY updatedAt DESC")
    fun observeFavorites(): Flow<List<ReadingItem>>

    @Query("SELECT * FROM reading_items WHERE id = :id LIMIT 1")
    fun observeById(id: Long): Flow<ReadingItem?>

    @Query("SELECT * FROM reading_items WHERE title LIKE :q OR url LIKE :q OR notes LIKE :q ORDER BY updatedAt DESC")
    fun search(q: String): Flow<List<ReadingItem>>

    @Insert
    suspend fun insert(item: ReadingItem): Long

    @Update
    suspend fun update(item: ReadingItem)

    @Delete
    suspend fun delete(item: ReadingItem)

    @Query("DELETE FROM reading_items")
    suspend fun clearAll()
}
