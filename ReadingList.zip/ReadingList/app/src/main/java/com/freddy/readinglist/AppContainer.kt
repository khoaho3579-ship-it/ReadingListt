package com.freddy.readinglist

import android.content.Context
import androidx.room.Room
import com.freddy.readinglist.data.ReadingDatabase
import com.freddy.readinglist.data.ReadingRepository
import com.freddy.readinglist.data.SettingsStore

class AppContainer(context: Context) {

    private val db = Room.databaseBuilder(
        context.applicationContext,
        ReadingDatabase::class.java,
        "reading.db"
    ).fallbackToDestructiveMigration().build()

    val repository = ReadingRepository(db.readingDao())
    val settings = SettingsStore(context.applicationContext)
}
