package com.freddy.readinglist.data

import androidx.room.Database
import androidx.room.RoomDatabase

@Database(entities = [ReadingItem::class], version = 1, exportSchema = false)
abstract class ReadingDatabase : RoomDatabase() {
    abstract fun readingDao(): ReadingDao
}
