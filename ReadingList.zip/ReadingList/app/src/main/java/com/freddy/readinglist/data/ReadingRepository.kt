package com.freddy.readinglist.data

import kotlinx.coroutines.flow.Flow

class ReadingRepository(private val dao: ReadingDao) {

    fun all(): Flow<List<ReadingItem>> = dao.observeAll()
    fun favorites(): Flow<List<ReadingItem>> = dao.observeFavorites()
    fun byId(id: Long): Flow<ReadingItem?> = dao.observeById(id)
    fun search(q: String): Flow<List<ReadingItem>> = dao.search("%${q.trim()}%")

    suspend fun create(title: String, url: String, notes: String): Long {
        val now = System.currentTimeMillis()
        return dao.insert(
            ReadingItem(
                title = title.trim(),
                url = url.trim(),
                notes = notes.trim(),
                createdAt = now,
                updatedAt = now
            )
        )
    }

    suspend fun update(item: ReadingItem) =
        dao.update(item.copy(updatedAt = System.currentTimeMillis()))

    suspend fun toggleFavorite(item: ReadingItem) =
        dao.update(item.copy(favorite = !item.favorite, updatedAt = System.currentTimeMillis()))

    suspend fun delete(item: ReadingItem) = dao.delete(item)
    suspend fun clearAll() = dao.clearAll()
}
