package com.freddy.readinglist.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.unit.dp

object ConnectedGroupShapes {
    val Leading = RoundedCornerShape(
        topStart = 28.dp, topEnd = 8.dp, bottomEnd = 8.dp, bottomStart = 28.dp
    )
    val Trailing = RoundedCornerShape(
        topStart = 8.dp, topEnd = 28.dp, bottomEnd = 28.dp, bottomStart = 8.dp
    )
}
