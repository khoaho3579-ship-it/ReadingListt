# Reading List (Android)

## Lấy APK không cần cài gì
1. Tạo repo GitHub, đẩy toàn bộ thư mục này lên (nhánh main).
2. Vào tab Actions -> "Build APK" -> chạy (Run workflow).
3. Tải artifact `ReadingList-release-apk` -> `app-release.apk`.

## Build trên máy
Cần JDK 17 + Android SDK (platform 35, build-tools 35). Chạy `./build_release.sh`.
APK: app/build/outputs/apk/release/app-release.apk

Đã sửa: SettingsScreen (favoritesOnly) và bỏ snackbar vô tác dụng trong EditScreen.
Khi phát hành thật: đặt KS_PASS / KEY_PASS, không commit release.keystore.
