#!/usr/bin/env bash
set -euo pipefail
# Needs: JDK 17, Android SDK (ANDROID_HOME), Gradle 8.9 (or an existing wrapper jar)
if [ ! -f release.keystore ]; then
  keytool -genkeypair -v -keystore release.keystore -alias release \
    -keyalg RSA -keysize 2048 -validity 10000 \
    -storepass freddyrelease -keypass freddyrelease \
    -dname "CN=ReadingList, OU=Freddy, O=Freddy, C=US"
fi
if [ ! -f gradle/wrapper/gradle-wrapper.jar ]; then
  gradle wrapper --gradle-version 8.9
fi
./gradlew clean assembleRelease
ls -l app/build/outputs/apk/release/app-release.apk
